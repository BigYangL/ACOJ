<template>
<div>
  <h1>Hi</h1>
</div>
</template>

<script>
export default {
  name: "IndexView"
}
</script>

<style scoped>

</style>