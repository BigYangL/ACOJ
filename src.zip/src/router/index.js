import { createRouter, createWebHistory } from 'vue-router'
import IndexView from '@/view/IndexView.vue'
import LoginView from "@/view/LoginView.vue";
import TestView from "@/view/TestView.vue";

const routes = [
    {
        path: '/',
        name: '首页',
        component: IndexView
    },
    {
        path: '/login',
        name: '登录界面',
        component: LoginView
    }
    // {
    //     path: '/test',
    //     name: 'test',
    //     component: TestView
    // }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router